/* MARK 4 · Combat HUD — light, single-canvas build. No dependencies. */
(function () {
'use strict';

var $ = function (id) { return document.getElementById(id); };
var cv = $('c'), cx = cv.getContext('2d');
var W = 0, H = 0, DPR = 1;
function resize() {
  DPR = Math.min(2, window.devicePixelRatio || 1);
  W = window.innerWidth; H = window.innerHeight;
  cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
  cx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
window.addEventListener('resize', resize); resize();

var COL = { ink: '#0b2a3f', mut: '#5b7c92', acc: '#0a84c6', acc2: '#18b6e8', hot: '#e8590c', warn: '#f59f00', ok: '#12a36b' };
var FONT = '600 13px Rajdhani, "Segoe UI", system-ui, sans-serif';
var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion:reduce)').matches;

/* ---------- persistence ---------- */
var hi = 0;
try { hi = +localStorage.getItem('mk4-light-hi') || 0; } catch (e) {}
function saveHi() { if (S.score > hi) { hi = S.score; try { localStorage.setItem('mk4-light-hi', hi); } catch (e) {} } }
$('hiStart').textContent = hi;

/* ---------- audio ---------- */
var AC = null;
function beep(f0, f1, d, type, v) {
  if (!S.sound) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    var t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + d);
    g.gain.setValueAtTime(v || .08, t);
    g.gain.exponentialRampToValueAtTime(.001, t + d);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d);
  } catch (e) {}
}

/* ---------- weapons ---------- */
var WP = [
  { n: 'REPULSOR', c: 4,  cd: .22 },
  { n: 'UNIBEAM',  c: 30, cd: 6 },
  { n: 'MISSILE',  c: 9,  cd: 1.1 },
  { n: 'MICRO x6', c: 20, cd: 4 },
  { n: 'EMP',      c: 35, cd: 12 }
];
var wpEl = $('wp');
WP.forEach(function (w, i) {
  w.t = 0;
  var b = document.createElement('button');
  b.className = 'w';
  b.innerHTML = '<b>' + (i + 1) + '</b><span>' + w.n + '</span><i></i>';
  b.setAttribute('aria-label', w.n);
  b.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
  b.addEventListener('click', function () { if (!S.run) return; if (S.sel === i) fire(i); else select(i); });
  wpEl.appendChild(b); w.el = b; w.bar = b.lastChild; w.lp = -1;
});
function select(i) { S.sel = i; WP.forEach(function (w, k) { w.el.classList.toggle('sel', k === i); }); beep(700, 900, .06, 'square', .04); }

/* ---------- state ---------- */
var S, en = [], shots = [], mis = [], fx = [], pk = [];
var aim = { x: 0, y: 0, rx: 0, ry: 0, moved: 0 };
var lockE = null, lastT = 0, time = 0, vig = 0;
var TYPES = [
  { n: 'SCOUT DRONE',  r: 22, hp: 2,  dmg: 4,  pts: 100, spd: 70 },
  { n: 'COMBAT WALKER', r: 28, hp: 4,  dmg: 6,  pts: 200, spd: 50 },
  { n: 'HEAVY WALKER',  r: 38, hp: 9,  dmg: 9,  pts: 400, spd: 36 },
  { n: 'BOSS',          r: 66, hp: 40, dmg: 10, pts: 3000, spd: 45 }
];

function reset() {
  S = {
    run: false, pause: false, over: false, sound: S ? S.sound : true,
    reactor: 100, suit: 100, score: 0, level: 0, kills: 0, quota: 0, spawned: 0, spawnT: 0,
    combo: 0, comboT: 0, sel: 0, shieldT: 0, shieldCd: 0, scanT: 0, scanCd: 0, auto: false, autoT: 0,
    dmgMul: 1, regen: 1, armor: 0, shieldLen: 4, between: false, nextT: 0,
    banner: '', bsub: '', bannerT: 0, msg: '', msgT: 0, queue: [], boss: false, perk: false, lastAct: 0
  };
  en = []; shots = []; mis = []; fx = []; pk = [];
  WP.forEach(function (w) { w.t = 0; });
  select(0);
}
S = { sound: true };
reset();

function say(t) { S.msg = t; S.msgT = 1.6; var m = $('msg'); m.textContent = t; m.classList.add('on'); }
function banner(t, sub) { S.banner = t; S.bsub = sub || ''; S.bannerT = 2.4; }

/* ---------- levels ---------- */
function startLevel(n) {
  S.level = n; S.between = false; S.kills = 0; S.spawned = 0; S.spawnT = .5;
  var boss = n % 5 === 0;
  S.quota = boss ? 3 : 4 + n * 2;
  S.boss = boss;
  S.reactor = 100; S.suit = Math.min(100, S.suit + 20);
  banner(boss ? 'BOSS FIGHT' : 'LEVEL ' + n, boss ? 'ELIMINATE THE WARLORD' : 'ELIMINATE ' + S.quota + ' HOSTILES');
  beep(300, 900, .3, 'square', .06);
  if (boss) spawn(3);
}
function spawn(type) {
  var T = TYPES[type], sc = 1 + (S.level - 1) * .1;
  var hp = Math.ceil(T.hp * sc);
  en.push({
    type: type, r: T.r, hp: hp, max: hp, x: 80 + Math.random() * (W - 160), y: -40, ty: 90 + Math.random() * Math.max(60, H * .35),
    vx: (Math.random() - .5) * T.spd * 2, vy: 0, fireT: 2 + Math.random() * 3, stun: 0, ph: Math.random() * 6.28, flash: 0, in: 1
  });
  S.spawned++;
}
function alive() { return en.length; }
function maxAlive() { return Math.min(7, 2 + Math.ceil(S.level / 2)); }

/* ---------- fx helpers ---------- */
function addFx(o) { if (fx.length < 220) fx.push(o); }
function ring(x, y, r0, r1, dur, col, w) { addFx({ k: 'r', x: x, y: y, r0: r0, r1: r1, t: 0, d: dur, col: col || COL.acc, w: w || 2 }); }
function line(x1, y1, x2, y2, w, dur, col) { addFx({ k: 'l', x1: x1, y1: y1, x2: x2, y2: y2, w: w, t: 0, d: dur, col: col || COL.acc2 }); }
function txt(x, y, s, col) { addFx({ k: 't', x: x, y: y, s: s, t: 0, d: .95, col: col || COL.ink }); }
function burst(x, y, n, col) {
  for (var i = 0; i < n; i++) {
    var a = Math.random() * 6.283, v = 60 + Math.random() * 180;
    addFx({ k: 'p', x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, d: .5 + Math.random() * .4, col: col || COL.hot });
  }
}

/* ---------- combat ---------- */
function nearest(x, y, maxD) {
  var b = null, bd = maxD || 1e9;
  for (var i = 0; i < en.length; i++) {
    var e = en[i], d = Math.hypot(e.x - x, e.y - y) - e.r;
    if (d < bd) { bd = d; b = e; }
  }
  return b;
}
function hurt(e, d) {
  if (e.hp <= 0 || e.in) return;
  d *= S.dmgMul; e.hp -= d; e.flash = .15;
  txt(e.x, e.y - e.r - 14, '-' + (Math.round(d * 10) / 10), COL.hot);
  ring(e.x, e.y, e.r * .5, e.r * 1.4, .35, COL.hot, 2);
  if (e.hp <= 0) kill(e); else beep(500, 160, .1, 'sawtooth', .04);
}
function kill(e) {
  var i = en.indexOf(e); if (i < 0) return; en.splice(i, 1);
  S.kills++; S.combo++; S.comboT = 5;
  var pts = TYPES[e.type].pts * Math.min(5, S.combo);
  S.score += pts; saveHi();
  txt(e.x, e.y - 8, '+' + pts, COL.warn);
  ring(e.x, e.y, 10, e.r * 3.2, .7, COL.warn, 3); ring(e.x, e.y, 6, e.r * 2, .5, COL.hot, 2);
  burst(e.x, e.y, e.type === 3 ? 40 : 16);
  beep(220, 40, .4, 'sawtooth', .09);
  if (e === lockE) lockE = null;
  if (e.type === 3 || Math.random() < .32) dropPk(e.x, e.y, e.type === 3 ? 3 : 0);
}
function dropPk(x, y, many) {
  var kinds = 'RRPPS';
  for (var i = 0; i <= many; i++) {
    var k = kinds[Math.floor(Math.random() * kinds.length)];
    pk.push({ x: Math.max(50, Math.min(W - 50, x + (i - many / 2) * 50)), y: Math.max(90, Math.min(H - 150, y)), k: k, age: 0 });
  }
}
function collect(p) {
  if (p.k === 'R') { S.suit = Math.min(100, S.suit + 30); say('SUIT REPAIR +30%'); }
  else if (p.k === 'P') { S.reactor = 100; WP.forEach(function (w) { w.t = Math.min(w.t, 1); }); say('POWER CELL · RECHARGED'); }
  else { S.shieldT = Math.max(S.shieldT, 5); say('SHIELD ONLINE'); }
  ring(p.x, p.y, 10, 60, .5, COL.ok, 3); beep(600, 1600, .2, 'sine', .07);
}
function origin(n) { return n ? { x: W * .7, y: H - 70 } : { x: W * .3, y: H - 70 }; }
var flip = 0;

function ready(i) { return WP[i].t <= 0 && S.reactor >= WP[i].c; }
function fire(i) {
  if (!S.run || S.pause || S.over) return;
  var w = WP[i];
  if (w.t > 0) { beep(120, 90, .08, 'square', .04); return; }
  if (S.reactor < w.c) { say('INSUFFICIENT POWER'); beep(120, 90, .12, 'square', .05); return; }
  var tgt = lockE || nearest(aim.x, aim.y, 140), o;
  if (i === 0) {
    flip ^= 1; o = origin(flip);
    var tx = tgt ? tgt.x : aim.x, ty = tgt ? tgt.y : aim.y;
    line(o.x, o.y, tx, ty, 4, .18, COL.acc2); ring(o.x, o.y, 6, 28, .2, COL.acc2, 2);
    if (tgt && Math.hypot(aim.x - tgt.x, aim.y - tgt.y) < tgt.r + 70) hurt(tgt, 1);
    beep(900, 140, .16, 'sawtooth', .05);
  } else if (i === 1) {
    o = { x: W / 2, y: H - 70 };
    var dx = aim.x - o.x, dy = aim.y - o.y, L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
    var ex = o.x + dx * 3000, ey = o.y + dy * 3000;
    line(o.x, o.y, ex, ey, 26, .5, 'rgba(24,182,232,.35)'); line(o.x, o.y, ex, ey, 7, .5, COL.acc);
    ring(o.x, o.y, 10, 120, .5, COL.acc, 3);
    en.slice().forEach(function (e) {
      var px = e.x - o.x, py = e.y - o.y, pr = px * dx + py * dy, d = Math.abs(px * dy - py * dx);
      if (pr > 0 && d < e.r + 26) hurt(e, 6);
    });
    beep(70, 500, .6, 'sawtooth', .1);
  } else if (i === 2) {
    if (!tgt) { say('NO TARGET · AIM AT A ROBOT'); return; }
    flip ^= 1; o = origin(flip);
    mis.push({ x: o.x, y: o.y, vx: (flip ? 1 : -1) * 120, vy: -380, tgt: tgt, d: 3, age: 0, big: 1 });
    beep(300, 60, .4, 'square', .06);
  } else if (i === 3) {
    if (!en.length) { say('NO TARGET'); return; }
    for (var k = 0; k < 6; k++) (function (k) { S.queue.push({ t: k * .09, f: function () {
      var t2 = en[Math.floor(Math.random() * en.length)]; if (!t2) return;
      var oo = origin(k & 1);
      mis.push({ x: oo.x, y: oo.y, vx: (Math.random() - .5) * 500, vy: -300 - Math.random() * 200, tgt: t2, d: 1, age: 0, big: 0 });
      beep(500, 120, .2, 'square', .04);
    } }); })(k);
  } else if (i === 4) {
    for (var r = 0; r < 3; r++) ring(W / 2, H * .55, 20, Math.max(W, H) * .7, 1 + r * .15, COL.acc, 3);
    en.forEach(function (e) { e.stun = 3; });
    shots.forEach(function (s) { burst(s.x, s.y, 6, COL.acc); }); shots = [];
    say('EMP · HOSTILES DISABLED'); beep(80, 30, 1, 'sine', .14);
  }
  S.reactor -= w.c; w.t = w.cd; S.lastAct = time;
}
function shield() {
  if (!S.run || S.pause) return;
  if (S.shieldCd > 0 || S.shieldT > 0) { beep(120, 90, .1, 'square', .04); return; }
  S.shieldT = S.shieldLen; S.shieldCd = 12 + S.shieldLen; say('SHIELD ONLINE');
  ring(W / 2, H - 80, 20, 220, .7, COL.acc, 3); beep(300, 1200, .35, 'sine', .08);
}
function scan() {
  if (!S.run || S.pause) return;
  if (S.scanCd > 0) { beep(120, 90, .1, 'square', .04); return; }
  S.scanT = 4.5; S.scanCd = 7; say('SCANNING · ' + en.length + ' HOSTILES'); beep(400, 1600, .6, 'sine', .06);
}

function playerHit(d) {
  if (S.shieldT > 0) {
    S.score += 25; ring(W / 2, H - 80, 30, 200, .5, COL.acc, 3); beep(1800, 600, .15, 'triangle', .06); return;
  }
  d = Math.max(1, Math.round(d * (1 - S.armor)));
  S.suit = Math.max(0, S.suit - d); S.combo = 0; vig = 1;
  say('HIT · SUIT ' + Math.round(S.suit) + '%'); beep(150, 40, .35, 'sawtooth', .12);
  if (S.suit <= 0) gameOver();
}

/* ---------- update ---------- */
function update(dt) {
  time += dt;
  /* queued actions */
  for (var q = S.queue.length - 1; q >= 0; q--) { S.queue[q].t -= dt; if (S.queue[q].t <= 0) { S.queue[q].f(); S.queue.splice(q, 1); } }

  S.reactor = Math.min(100, S.reactor + 6 * S.regen * dt);
  WP.forEach(function (w) { if (w.t > 0) w.t = Math.max(0, w.t - dt); });
  S.shieldT = Math.max(0, S.shieldT - dt); S.shieldCd = Math.max(0, S.shieldCd - dt);
  S.scanT = Math.max(0, S.scanT - dt); S.scanCd = Math.max(0, S.scanCd - dt);
  if (S.comboT > 0) { S.comboT -= dt; if (S.comboT <= 0) S.combo = 0; }
  if (S.bannerT > 0) S.bannerT -= dt;
  if (S.msgT > 0) { S.msgT -= dt; if (S.msgT <= 0) $('msg').classList.remove('on'); }
  vig = Math.max(0, vig - dt * 1.6);

  /* aim smoothing + lock */
  var near = nearest(aim.x, aim.y, 110);
  lockE = near;
  var gx = lockE ? lockE.x : aim.x, gy = lockE ? lockE.y : aim.y;
  var k = 1 - Math.pow(.0005, dt * (lockE ? 1.4 : 1));
  aim.rx += (gx - aim.rx) * k; aim.ry += (gy - aim.ry) * k;

  /* spawn */
  if (!S.between) {
    S.spawnT -= dt;
    var needBoss = S.boss;
    if (S.spawnT <= 0 && alive() < maxAlive() && S.spawned < S.quota) {
      if (!(needBoss && S.spawned === 0)) {
        var r = Math.random(), ty = r < .55 ? 0 : (r < .85 || S.level < 3 ? 1 : 2);
        if (S.level < 2 && ty > 0 && Math.random() < .5) ty = 0;
        spawn(ty);
      }
      S.spawnT = 1.4;
    }
    /* clear condition */
    var done = needBoss ? (S.spawned > 0 && !en.some(function (e) { return e.type === 3; })) : (S.kills >= S.quota && !en.length);
    if (done) {
      S.between = true; S.nextT = 2.6; var b = 500 * S.level; S.score += b; saveHi();
      shots = []; en.forEach(function (e) { burst(e.x, e.y, 14); }); en = []; banner(needBoss ? 'BOSS DEFEATED' : 'LEVEL COMPLETE', 'BONUS +' + b);
      beep(600, 1500, .4, 'square', .07);
    }
  } else {
    S.nextT -= dt;
    if (S.nextT <= 0) { showPerks(); }
  }

  /* enemies */
  var lvlMul = 1 + S.level * .05;
  for (var i = en.length - 1; i >= 0; i--) {
    var e = en[i], T = TYPES[e.type];
    e.flash = Math.max(0, e.flash - dt);
    if (e.in) { e.y += (e.ty - e.y) * Math.min(1, dt * 3); if (Math.abs(e.ty - e.y) < 6) e.in = 0; continue; }
    if (e.stun > 0) { e.stun -= dt; continue; }
    e.x += e.vx * dt; e.y += Math.sin(time * .8 + e.ph) * 14 * dt;
    if (e.x < e.r + 10) { e.x = e.r + 10; e.vx = Math.abs(e.vx); }
    if (e.x > W - e.r - 10) { e.x = W - e.r - 10; e.vx = -Math.abs(e.vx); }
    if (Math.random() < dt * .4) e.vx = (Math.random() - .5) * T.spd * 2.4;
    e.fireT -= dt;
    if (e.fireT <= 0) {
      e.fireT = (e.type === 3 ? 1.9 : 3 + Math.random() * 3.5) / (1 + S.level * .05);
      var n = e.type === 3 ? 3 : 1;
      for (var s = 0; s < n; s++) shots.push({
        sx: e.x, sy: e.y, x: e.x, y: e.y, tx: W / 2 + (Math.random() - .5) * 240, ty: H - 80,
        t: 0, dur: 1.6 + Math.random() * .5 - Math.min(.5, S.level * .03), d: T.dmg * lvlMul, e: e
      });
      ring(e.x, e.y, e.r, e.r * 1.8, .4, COL.hot, 2); beep(400, 1000, .25, 'sine', .03);
    }
  }
  /* enemy shots */
  for (var j = shots.length - 1; j >= 0; j--) {
    var sh = shots[j]; sh.t += dt / sh.dur;
    var u = sh.t * .6 + sh.t * sh.t * .4;
    sh.x = sh.sx + (sh.tx - sh.sx) * u; sh.y = sh.sy + (sh.ty - sh.sy) * u;
    if (sh.t >= 1) { shots.splice(j, 1); playerHit(sh.d); }
  }
  /* player missiles */
  for (var m = mis.length - 1; m >= 0; m--) {
    var ms = mis[m]; ms.age += dt;
    if (!ms.tgt || en.indexOf(ms.tgt) < 0) ms.tgt = nearest(ms.x, ms.y);
    var tg = ms.tgt, tx = tg ? tg.x : ms.x, ty = tg ? tg.y : ms.y - 100;
    var ddx = tx - ms.x, ddy = ty - ms.y, dd = Math.hypot(ddx, ddy) || 1, sp = ms.big ? 760 : 900;
    ms.vx += (ddx / dd * sp - ms.vx) * Math.min(1, dt * 7); ms.vy += (ddy / dd * sp - ms.vy) * Math.min(1, dt * 7);
    ms.px = ms.x; ms.py = ms.y; ms.x += ms.vx * dt; ms.y += ms.vy * dt;
    addFx({ k: 'l', x1: ms.px, y1: ms.py, x2: ms.x, y2: ms.y, w: ms.big ? 3 : 2, t: 0, d: .25, col: COL.warn });
    if (!tg || dd < (tg.r + 8) || ms.age > 4) {
      mis.splice(m, 1);
      if (tg && dd < tg.r + 20) hurt(tg, ms.d);
      ring(ms.x, ms.y, 6, ms.big ? 60 : 30, .4, COL.warn, 2); burst(ms.x, ms.y, 6, COL.warn); beep(900, 80, .25, 'sawtooth', .05);
    }
  }
  /* pickups */
  for (var p = pk.length - 1; p >= 0; p--) {
    var c = pk[p]; c.age += dt;
    if (Math.hypot(c.x - aim.x, c.y - aim.y) < 52 || (S.auto && c.age > 1.2)) { collect(c); pk.splice(p, 1); }
    else if (c.age > 10) pk.splice(p, 1);
  }
  /* fx */
  for (var f = fx.length - 1; f >= 0; f--) {
    var o = fx[f]; o.t += dt;
    if (o.k === 'p') { o.x += o.vx * dt; o.y += o.vy * dt; o.vx *= .96; o.vy = o.vy * .96 + 60 * dt; }
    if (o.t >= o.d) fx.splice(f, 1);
  }
  if (S.auto) autoPlay(dt);
}

function autoPlay(dt) {
  S.autoT -= dt; if (S.autoT > 0 || S.between) return; S.autoT = .18;
  var t = null, bd = 1e9;
  en.forEach(function (e) { if (e.in) return; var d = Math.hypot(e.x - W / 2, e.y - H); if (d < bd) { bd = d; t = e; } });
  if (!t) return;
  aim.x = t.x; aim.y = t.y;
  if (shots.length && S.suit < 85) shield();
  if (S.scanCd <= 0 && Math.random() < .1) scan();
  var strong = t.type >= 2 || t.hp > 5;
  if (strong && ready(1)) fire(1);
  else if (en.length >= 3 && ready(3)) fire(3);
  else if (ready(2) && S.reactor > 50) fire(2);
  else if (ready(0)) fire(0);
  if (shots.length >= 2 && ready(4) && S.reactor > 60) fire(4);
}

/* ---------- perks / game flow ---------- */
var PERKS = [
  ['FIREPOWER', 'Weapon damage +20%', function () { S.dmgMul += .2; }],
  ['OVERCHARGE', 'Reactor recharges 30% faster', function () { S.regen += .3; }],
  ['PLATING', 'Incoming damage -12%', function () { S.armor = Math.min(.6, S.armor + .12); }],
  ['SHIELD MK2', 'Shield lasts +1s', function () { S.shieldLen += 1; }],
  ['NANO REPAIR', 'Restore 35% suit now', function () { S.suit = Math.min(100, S.suit + 35); }]
];
function showPerks() {
  S.pause = true; S.perk = true;
  var list = $('perkList'); list.innerHTML = '';
  PERKS.slice().sort(function () { return Math.random() - .5; }).slice(0, 3).forEach(function (p) {
    var b = document.createElement('button');
    b.innerHTML = '<b>' + p[0] + '</b><span>' + p[1] + '</span>';
    b.onclick = function () { p[2](); S.perk = false; S.pause = false; $('perk').classList.add('hidden'); startLevel(S.level + 1); beep(500, 1800, .3, 'sine', .08); };
    list.appendChild(b);
  });
  $('perk').classList.remove('hidden');
}
function gameOver() {
  S.over = true; S.run = false; saveHi();
  $('overTxt').textContent = 'SCORE ' + S.score + ' · LEVEL ' + S.level + ' · BEST ' + hi;
  $('over').classList.remove('hidden'); beep(200, 30, 1.2, 'sawtooth', .12);
}
function startGame() {
  var snd = S.sound; reset(); S.sound = snd; S.run = true; S.lastAct = 0;
  aim.x = aim.rx = W / 2; aim.y = aim.ry = H * .4;
  ['start', 'over', 'perk', 'pause'].forEach(function (id) { $(id).classList.add('hidden'); });
  startLevel(1); $('hiStart').textContent = hi; syncBtns();
}
function setPause(v) {
  if (!S.run || S.perk) return;
  S.pause = v; $('pause').classList.toggle('hidden', !v); $('bPause').textContent = v ? 'RESUME' : 'PAUSE';
}
function setAuto(v) { S.auto = v; $('bAuto').setAttribute('aria-pressed', v); if (v) say('AUTO MODE ENGAGED'); }
function syncBtns() {
  $('bSnd').setAttribute('aria-pressed', S.sound); $('bAuto').setAttribute('aria-pressed', S.auto);
}

/* ---------- drawing ---------- */
function draw() {
  var g = cx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#f6fbfe'); g.addColorStop(1, '#d9eaf5');
  cx.fillStyle = g; cx.fillRect(0, 0, W, H);
  drawGrid(); drawRings(); drawPickups(); drawEnemies(); drawShots(); drawFx();
  drawReticle(); drawHud();
  if (vig > 0) {
    var v = cx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * .3, W / 2, H / 2, Math.max(W, H) * .75);
    v.addColorStop(0, 'rgba(232,89,12,0)'); v.addColorStop(1, 'rgba(232,89,12,' + (vig * .45).toFixed(2) + ')');
    cx.fillStyle = v; cx.fillRect(0, 0, W, H);
  }
  if (S.suit < 30 && S.run && !S.pause) {
    cx.fillStyle = 'rgba(232,89,12,' + (.05 + .05 * Math.sin(time * 6)).toFixed(3) + ')'; cx.fillRect(0, 0, W, H);
  }
  if (S.shieldT > 0) drawShield();
  if (S.bannerT > 0) drawBanner();
}
function drawGrid() {
  cx.strokeStyle = 'rgba(10,132,198,.09)'; cx.lineWidth = 1; cx.beginPath();
  var step = 48, ox = reduce ? 0 : (aim.rx - W / 2) * -.03, oy = reduce ? 0 : (aim.ry - H / 2) * -.03;
  for (var x = (ox % step) - step; x < W + step; x += step) { cx.moveTo(x, 0); cx.lineTo(x, H); }
  for (var y = (oy % step) - step; y < H + step; y += step) { cx.moveTo(0, y); cx.lineTo(W, y); }
  cx.stroke();
}
function arc(x, y, r, a0, a1) { cx.beginPath(); cx.arc(x, y, r, a0, a1); cx.stroke(); }
function drawRings() {
  var R = Math.min(W, H) * (W < 640 ? .17 : .2), x = W - R - 24, y = H * .5;
  if (W < 640) { x = W - R - 14; y = H * .42; }
  cx.save(); cx.lineWidth = 1.2; cx.strokeStyle = 'rgba(10,132,198,.28)';
  var t = reduce ? 0 : time;
  cx.setLineDash([2, 7]); cx.lineWidth = 8; arc(x, y, R * 1.12, t * .15, t * .15 + 6.283); cx.setLineDash([]);
  cx.lineWidth = 1.2; arc(x, y, R, 0, 6.283);
  cx.lineWidth = 3; cx.strokeStyle = 'rgba(10,132,198,.45)';
  arc(x, y, R * .86, t * .5, t * .5 + 1.7); arc(x, y, R * .86, t * .5 + 3.1, t * .5 + 4.6);
  cx.lineWidth = 6; cx.strokeStyle = COL.acc; arc(x, y, R * .66, -1.5708, -1.5708 + 6.283 * S.reactor / 100);
  cx.lineWidth = 1; cx.strokeStyle = 'rgba(10,132,198,.4)'; arc(x, y, R * .5, -t * .4, -t * .4 + 3.5);
  cx.fillStyle = COL.ink; cx.font = '700 ' + Math.round(R * .3) + 'px Rajdhani, system-ui, sans-serif'; cx.textAlign = 'center'; cx.textBaseline = 'middle';
  cx.fillText(Math.round(S.reactor) + '%', x, y - 2);
  cx.font = FONT; cx.fillStyle = COL.mut; cx.fillText('REACTOR', x, y + R * .22);
  cx.restore();
}
function drawEnemy(e) {
  var bob = Math.sin(time * 3 + e.ph) * 3, r = e.r, a = e.stun > 0 ? .4 : 1;
  cx.save(); cx.translate(e.x, e.y + bob); cx.globalAlpha = a;
  cx.lineWidth = 2; cx.lineJoin = 'round'; cx.strokeStyle = e.flash > 0 ? COL.hot : COL.ink;
  cx.fillStyle = e.flash > 0 ? 'rgba(232,89,12,.35)' : 'rgba(255,255,255,.85)';
  if (e.type === 0) {
    cx.beginPath(); cx.arc(0, 0, r, 0, 6.283); cx.fill(); cx.stroke();
    cx.beginPath(); cx.moveTo(-r - 14, -8); cx.lineTo(-r + 4, -8); cx.moveTo(r + 14, -8); cx.lineTo(r - 4, -8); cx.stroke();
    cx.fillStyle = COL.hot; cx.beginPath(); cx.arc(0, 0, r * .3, 0, 6.283); cx.fill();
  } else if (e.type === 1 || e.type === 2) {
    var s = r / 28;
    cx.beginPath(); cx.rect(-9 * s, -34 * s, 18 * s, 13 * s); cx.fill(); cx.stroke();
    cx.beginPath(); cx.moveTo(-17 * s, -18 * s); cx.lineTo(17 * s, -18 * s); cx.lineTo(12 * s, 12 * s); cx.lineTo(-12 * s, 12 * s); cx.closePath(); cx.fill(); cx.stroke();
    cx.beginPath(); cx.moveTo(-17 * s, -16 * s); cx.lineTo(-25 * s, 6 * s); cx.moveTo(17 * s, -16 * s); cx.lineTo(25 * s, 6 * s);
    cx.moveTo(-6 * s, 12 * s); cx.lineTo(-8 * s, 30 * s); cx.moveTo(6 * s, 12 * s); cx.lineTo(8 * s, 30 * s); cx.stroke();
    cx.fillStyle = COL.hot; cx.fillRect(-6 * s, -30 * s, 12 * s, 4 * s);
    cx.beginPath(); cx.arc(0, -4 * s, 4 * s, 0, 6.283); cx.fill();
    if (e.type === 2) { cx.fillStyle = 'rgba(255,255,255,.9)'; cx.fillRect(-30 * s, -24 * s, 10 * s, 14 * s); cx.strokeRect(-30 * s, -24 * s, 10 * s, 14 * s); cx.fillRect(20 * s, -24 * s, 10 * s, 14 * s); cx.strokeRect(20 * s, -24 * s, 10 * s, 14 * s); }
  } else {
    cx.beginPath(); for (var i = 0; i < 6; i++) { var an = i * 1.0472 + time * .2; cx.lineTo(Math.cos(an) * r, Math.sin(an) * r); } cx.closePath(); cx.fill(); cx.stroke();
    cx.setLineDash([6, 8]); arc(0, 0, r * 1.25, time * .6, time * .6 + 6.283); cx.setLineDash([]);
    cx.fillStyle = COL.hot; cx.beginPath(); cx.arc(0, 0, r * .28, 0, 6.283); cx.fill();
    cx.beginPath(); cx.arc(0, 0, r * .55, 0, 6.283); cx.stroke();
  }
  cx.restore();
  /* hp bar */
  var bw = Math.max(34, r * 1.6), by = e.y - r - 16 + bob;
  cx.fillStyle = 'rgba(11,42,63,.12)'; cx.fillRect(e.x - bw / 2, by, bw, 4);
  cx.fillStyle = e.hp / e.max < .35 ? COL.hot : COL.acc; cx.fillRect(e.x - bw / 2, by, bw * Math.max(0, e.hp / e.max), 4);
}
function drawEnemies() {
  cx.textAlign = 'center'; cx.textBaseline = 'alphabetic'; cx.font = FONT;
  for (var i = 0; i < en.length; i++) {
    var e = en[i]; drawEnemy(e);
    if (S.scanT > 0) {
      var thr = TYPES[e.type].dmg >= 9 ? 'HIGH' : TYPES[e.type].dmg >= 6 ? 'MED' : 'LOW', col = thr === 'HIGH' ? COL.hot : thr === 'MED' ? COL.warn : COL.acc;
      cx.strokeStyle = col; cx.lineWidth = 1.5; cx.setLineDash([5, 5]); arc(e.x, e.y, e.r + 12, time, time + 6.283); cx.setLineDash([]);
      cx.fillStyle = col; cx.fillText(TYPES[e.type].n + ' · ' + thr + ' · ' + Math.round(e.hp) + '/' + e.max, e.x, e.y + e.r + 28);
    }
    if (e === lockE) { cx.fillStyle = COL.hot; cx.fillText('LOCK', e.x, e.y + e.r + 18); }
  }
}
function drawShots() {
  for (var i = 0; i < shots.length; i++) {
    var s = shots[i];
    cx.strokeStyle = 'rgba(232,89,12,.35)'; cx.lineWidth = 1.5; cx.setLineDash([5, 6]);
    cx.beginPath(); cx.moveTo(s.x, s.y); cx.lineTo(s.tx, s.ty); cx.stroke(); cx.setLineDash([]);
    cx.strokeStyle = COL.hot; cx.lineWidth = 2; cx.beginPath(); cx.moveTo(s.sx + (s.x - s.sx) * .8, s.sy + (s.y - s.sy) * .8); cx.lineTo(s.x, s.y); cx.stroke();
    cx.fillStyle = COL.hot; cx.beginPath(); cx.arc(s.x, s.y, 5 + s.t * 9, 0, 6.283); cx.fill();
  }
  if (shots.length) {
    var m = 9; shots.forEach(function (s) { m = Math.min(m, (1 - s.t) * s.dur); });
    cx.fillStyle = COL.hot; cx.font = '700 15px Rajdhani, system-ui, sans-serif'; cx.textAlign = 'center';
    cx.fillText('▲ INCOMING ' + m.toFixed(1) + 's', W / 2, 112);
  }
}
function drawPickups() {
  cx.font = '700 16px Rajdhani, system-ui, sans-serif'; cx.textAlign = 'center'; cx.textBaseline = 'middle';
  for (var i = 0; i < pk.length; i++) {
    var p = pk[i], c = p.k === 'R' ? COL.ok : p.k === 'P' ? COL.warn : COL.acc;
    if (p.age > 7.5 && Math.floor(p.age * 6) % 2) continue;
    var y = p.y + Math.sin(p.age * 3) * 4;
    cx.fillStyle = 'rgba(255,255,255,.9)'; cx.strokeStyle = c; cx.lineWidth = 2; cx.beginPath(); cx.arc(p.x, y, 17, 0, 6.283); cx.fill(); cx.stroke();
    cx.setLineDash([3, 5]); arc(p.x, y, 24, p.age * 2, p.age * 2 + 6.283); cx.setLineDash([]);
    cx.fillStyle = c; cx.fillText(p.k, p.x, y + 1);
  }
  cx.textBaseline = 'alphabetic';
}
function drawFx() {
  cx.textAlign = 'center';
  for (var i = 0; i < fx.length; i++) {
    var o = fx[i], u = o.t / o.d, a = 1 - u;
    if (o.k === 'r') { cx.globalAlpha = a; cx.strokeStyle = o.col; cx.lineWidth = o.w; arc(o.x, o.y, o.r0 + (o.r1 - o.r0) * (1 - a * a), 0, 6.283); }
    else if (o.k === 'l') { cx.globalAlpha = a; cx.strokeStyle = o.col; cx.lineWidth = o.w; cx.beginPath(); cx.moveTo(o.x1, o.y1); cx.lineTo(o.x2, o.y2); cx.stroke(); }
    else if (o.k === 't') { cx.globalAlpha = a; cx.fillStyle = o.col; cx.font = '700 16px Rajdhani, system-ui, sans-serif'; cx.fillText(o.s, o.x, o.y - u * 40); }
    else { cx.globalAlpha = a; cx.fillStyle = o.col; cx.fillRect(o.x - 2, o.y - 2, 4, 4); }
  }
  cx.globalAlpha = 1;
}
function drawReticle() {
  if (!S.run) return;
  var x = aim.rx, y = aim.ry, lk = !!lockE, col = lk ? COL.hot : COL.acc, t = reduce ? 0 : time;
  cx.save(); cx.translate(x, y); cx.strokeStyle = col; cx.lineWidth = 2;
  var sc = lk ? 1.1 : .9; cx.scale(sc, sc);
  cx.beginPath(); cx.arc(0, 0, 30, 0, 6.283); cx.stroke();
  cx.lineWidth = 1.5; cx.setLineDash([10, 6]); arc(0, 0, 42, t * (lk ? 3 : 1), t * (lk ? 3 : 1) + 6.283); cx.setLineDash([]);
  cx.lineWidth = 3; arc(0, 0, 52, t * .8, t * .8 + 1); arc(0, 0, 52, t * .8 + 3.14, t * .8 + 4.14);
  cx.lineWidth = 2; cx.beginPath(); cx.moveTo(0, -38); cx.lineTo(0, -62); cx.moveTo(0, 38); cx.lineTo(0, 62); cx.moveTo(-38, 0); cx.lineTo(-62, 0); cx.moveTo(38, 0); cx.lineTo(62, 0); cx.stroke();
  cx.fillStyle = col; cx.beginPath(); cx.arc(0, 0, 3.5, 0, 6.283); cx.fill();
  cx.restore();
  cx.fillStyle = col; cx.font = FONT; cx.textAlign = 'left';
  cx.fillText(lk ? 'LOCK · ' + TYPES[lockE.type].n : 'TRACKING', x + 58, y + 62);
}
function bar(x, y, w, v, col, label, val) {
  cx.fillStyle = COL.mut; cx.font = FONT; cx.textAlign = 'left'; cx.fillText(label, x, y - 4);
  cx.textAlign = 'right'; cx.fillStyle = COL.ink; cx.fillText(val, x + w, y - 4);
  cx.fillStyle = 'rgba(11,42,63,.12)'; cx.fillRect(x, y, w, 7);
  cx.fillStyle = col; cx.fillRect(x, y, w * Math.max(0, Math.min(1, v)), 7);
}
function drawHud() {
  var bw = Math.min(190, W * .34), top = 26;
  bar(14, top, bw, S.suit / 100, S.suit < 30 ? COL.hot : COL.ok, 'SUIT', Math.round(S.suit) + '%');
  bar(14, top + 30, bw, S.reactor / 100, COL.acc, 'POWER', Math.round(S.reactor) + '%');
  cx.textAlign = 'center'; cx.fillStyle = COL.ink; cx.font = '700 17px Rajdhani, system-ui, sans-serif';
  cx.fillText('LEVEL ' + Math.max(1, S.level) + (S.boss ? ' · BOSS' : '') + '   ' + S.score + ' PTS', W / 2, 30);
  cx.font = FONT; cx.fillStyle = COL.mut;
  cx.fillText((S.boss ? 'BOSS FIGHT' : 'HOSTILES ' + Math.min(S.kills, S.quota) + '/' + S.quota) + '   BEST ' + hi + (S.combo > 1 ? '   COMBO x' + Math.min(5, S.combo) : ''), W / 2, 50);
  if (S.auto) { cx.fillStyle = COL.hot; cx.fillText('AUTO', W / 2, 68); }
  /* button states */
  var sb = $('bShield'), sc = $('bScan');
  var st = S.shieldT > 0 ? 'ACTIVE ' + Math.ceil(S.shieldT) : S.shieldCd > 0 ? 'SHIELD ' + Math.ceil(S.shieldCd) + 's' : 'SHIELD';
  if (sb.textContent !== st) sb.textContent = st; sb.disabled = S.shieldCd > 0 && S.shieldT <= 0;
  var ss = S.scanCd > 0 ? 'SCAN ' + Math.ceil(S.scanCd) + 's' : 'SCAN';
  if (sc.textContent !== ss) sc.textContent = ss; sc.disabled = S.scanCd > 0;
  WP.forEach(function (w) {
    var p = w.t > 0 ? 1 - w.t / w.cd : 1, pp = Math.round(p * 40);
    if (pp !== w.lp) { w.lp = pp; w.bar.style.setProperty('--p', p.toFixed(2)); w.bar.style.width = (p * 100).toFixed(0) + '%'; w.el.classList.toggle('cd', p < 1); }
    w.el.style.opacity = S.reactor < w.c && p >= 1 ? .55 : '';
  });
}
function drawShield() {
  var a = Math.min(1, S.shieldT) * .9, cxs = W / 2, cys = H - 80, r = Math.max(W, H) * .38;
  var g = cx.createRadialGradient(cxs, cys, r * .6, cxs, cys, r);
  g.addColorStop(0, 'rgba(24,182,232,0)'); g.addColorStop(1, 'rgba(24,182,232,' + (.22 * a).toFixed(3) + ')');
  cx.fillStyle = g; cx.fillRect(0, 0, W, H);
  cx.strokeStyle = 'rgba(10,132,198,' + (.5 * a).toFixed(2) + ')'; cx.lineWidth = 2; cx.setLineDash([12, 10]); arc(cxs, cys, r * .9, Math.PI, 2 * Math.PI); cx.setLineDash([]);
}
function drawBanner() {
  var u = S.bannerT / 2.4, a = u > .85 ? (1 - u) / .15 : u < .25 ? u / .25 : 1;
  cx.save(); cx.globalAlpha = Math.max(0, Math.min(1, a)); cx.textAlign = 'center';
  cx.fillStyle = COL.ink; cx.font = '700 ' + Math.min(56, W * .09) + 'px Rajdhani, system-ui, sans-serif';
  cx.fillText(S.banner.split('').join(String.fromCharCode(8202)), W / 2, H * .3);
  cx.strokeStyle = COL.acc; cx.lineWidth = 2; cx.beginPath(); cx.moveTo(W / 2 - 150, H * .3 + 14); cx.lineTo(W / 2 + 150, H * .3 + 14); cx.stroke();
  cx.fillStyle = COL.acc; cx.font = '600 16px Rajdhani, system-ui, sans-serif'; cx.fillText(S.bsub, W / 2, H * .3 + 38);
  cx.restore();
}

/* ---------- input ---------- */
function setAim(e) { aim.x = e.clientX; aim.y = e.clientY; aim.moved = time; }
cv.addEventListener('pointermove', function (e) { if (!S.auto) setAim(e); });
cv.addEventListener('pointerdown', function (e) {
  if (!S.run || S.pause) return;
  if (!S.auto) setAim(e);
  if (e.pointerType === 'touch') { aim.rx = aim.x; aim.ry = aim.y; }
  fire(S.sel);
  if (!S.auto) { holdId = setInterval(function () { if (S.sel === 0) fire(0); }, 120); }
});
var holdId = 0;
function stopHold() { clearInterval(holdId); holdId = 0; }
['pointerup', 'pointercancel', 'pointerleave'].forEach(function (n) { cv.addEventListener(n, stopHold); });
cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });

window.addEventListener('keydown', function (e) {
  var k = e.key.toLowerCase();
  if (!S.run && !S.over && !$('start').classList.contains('hidden') && (k === 'enter' || k === ' ')) { e.preventDefault(); startGame(); return; }
  if (S.over && k === 'enter') { startGame(); return; }
  if (k === 'p' || k === 'escape') { setPause(!S.pause); return; }
  if (!S.run || S.pause) return;
  if (k >= '1' && k <= '5') select(+k - 1);
  else if (k === ' ') { e.preventDefault(); fire(S.sel); }
  else if (k === 'x') shield();
  else if (k === 's') scan();
  else if (k === 'a') setAuto(!S.auto);
  else if (k === 'm') { S.sound = !S.sound; syncBtns(); }
});
$('bStart').onclick = startGame;
$('bRetry').onclick = startGame;
$('bResume').onclick = function () { setPause(false); };
$('bPause').onclick = function () { setPause(!S.pause); };
$('bShield').onclick = shield;
$('bScan').onclick = scan;
$('bAuto').onclick = function () { if (S.run) setAuto(!S.auto); };
$('bSnd').onclick = function () { S.sound = !S.sound; syncBtns(); };
['top'].forEach(function (id) { $(id).addEventListener('pointerdown', function (e) { e.stopPropagation(); }); });
document.addEventListener('visibilitychange', function () { if (document.hidden) setPause(true); });

/* ---------- loop ---------- */
function loop(now) {
  requestAnimationFrame(loop);
  var dt = Math.min(.05, (now - lastT) / 1000 || 0); lastT = now;
  if (S.run && !S.pause) update(dt);
  else if (!S.run) { time += dt; aim.rx += (aim.x - aim.rx) * .1; aim.ry += (aim.y - aim.ry) * .1; }
  draw();
}
aim.x = aim.rx = W / 2; aim.y = aim.ry = H * .4;
requestAnimationFrame(loop);

/* ---------- PWA ---------- */
if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) {
  window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
}
})();
