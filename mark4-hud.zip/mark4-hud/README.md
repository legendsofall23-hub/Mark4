# MARK 4 · Combat HUD

A light, fast browser game. Pure HTML + CSS + one canvas. No build step, no dependencies.

**Play:** `https://YOUR-USERNAME.github.io/mark4-hud/`

## Controls
- Move / drag: aim · Click / tap / Space: fire selected weapon · 1–5: select weapon
- X shield · S scan · A auto · M sound · P pause
- Touch pickups (R repair, P power, S shield) with the reticle.

## Publish on GitHub Pages
1. Create a new repo named `mark4-hud` on github.com.
2. Upload every file in this folder (keep `.nojekyll`), or:
   `git init && git add . && git commit -m "MARK 4" && git branch -M main && git remote add origin https://github.com/YOUR-USERNAME/mark4-hud.git && git push -u origin main`
3. Repo **Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save**.
4. Wait ~1 minute. Your site is live at the URL above.

## Files
`index.html` page · `style.css` light theme · `game.js` game · `sw.js` + `manifest.json` offline/installable · `icon.svg`
